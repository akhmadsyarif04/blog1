<html>
<head>
  <link rel="stylesheet" type="text/css" href="css.css">
  <link rel="stylesheet" type="text/css" href="menu-navigation.css">

  <title>Halaman Utama</title>

</head>
<body>

  <?php
    include('menu.php');
  ?>


  <div id="isi">
  </div>

  <?php
      include('footer.html');
  ?>
</body>
</html>
