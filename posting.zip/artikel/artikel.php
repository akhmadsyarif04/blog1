<!doctype>
<html>
<head>
    <meta charset="utf-8">
    <title> ARTIKEL </title>
    <link rel="stylesheet" type="text/css" href="../css.css">

</head>
<body>

<div id="header">
  <a title="Back To Home" href="../index.php"><img src="gambar/back.png"></a>
<b><center>[ ARTIKEL ]</center></b>
</div>
<?php
  include('box.html');
  include('../footer.html');
?>
</body>
</html>
