<!doctype>
<html>
<head>
    <meta charset="utf-8">
    <title>Kegunaan C/C++</title>
    <link rel="stylesheet" type="text/css" href="../css.css">
    <link rel="stylesheet" type="text/css" href="../menu-navigation.css">
    <link rel="stylesheet" type="text/css" href="../css.css">

</head>
<body>
<?php
  include('menu.php');
?>
<div id="header">
<center class="judul" >C/C++ Tak Sebatas Untuk Kuliah </center>
</div>
<?php
  include('../editor_online.html');
  include('c++/kegunaan.html');
  include('../footer.html');
?>
</body>
</html>
