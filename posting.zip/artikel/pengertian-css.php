<!doctype>
<html>
<head>
    <meta charset="utf-8">
    <title>Penjelasan tentang CSS</title>
    <link rel="stylesheet" type="text/css" href="../css.css">
    <link rel="stylesheet" type="text/css" href="../menu-navigation.css">
</head>
<body>
<?php
  include('menu.php');
?>
<div id="header">
<b><center>Pengertian CSS</center></b>
</div>
<?php
  include('../editor_online.html');
  include('css/pengertian.html');
  include('../footer.html');
?>
</body>
</html>
