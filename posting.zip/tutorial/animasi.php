<html>
<head>
    <link rel="stylesheet" type="text/css" href="../css.css">
    <title>Membuat Animasi Pada HTML</title>
    <link rel="stylesheet" type="text/css" href="../menu-navigation.css">
</head>
<body>
<?php
  include('menu.php');
?>

<div id="header">
<b><center>Membuat animasi pada html</center></b>
</div>

<?php
  include('../editor_online.html');
  include('CSS/animasi-css3.html');
  include('../footer.html');
  ?>
</body>
</html>
