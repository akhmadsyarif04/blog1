<html>
<head>
    <link rel="stylesheet" type="text/css" href="../css.css">
    <title>Style link dengan CSS</title>
    <link rel="stylesheet" type="text/css" href="../menu-navigation.css">
</head>
<body>
<?php
  include('menu.php');
?>

<div id="header">
<b><center>Style link dengan CSS</center></b>
</div>

<?php
  include('../editor_online.html');
  include('CSS/hover.html');
  include('../footer.html');
  ?>
</body>
</html>
