<html>
<head>
    <link rel="stylesheet" type="text/css" href="../css.css">
    <title>Membuat koneksi database dengan PHP</title>
    <link rel="stylesheet" type="text/css" href="../menu-navigation.css">
</head>
<body>
<?php
  include('menu.php');
?>

<div id="header">
<b><center>Membuat Koneksi Database dengan PHP</center></b>
</div>

<?php
  include('../editor_online.html');
  include('PHP/connect.html');
  include('../footer.html');
  ?>
</body>
</html>
